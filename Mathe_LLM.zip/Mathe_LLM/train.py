#!/usr/bin/env python3
# /// script
# requires-python = ">=3.10"
# dependencies = [
#     "torch==2.10.0",
#     "transformers==4.57.1",
# ]
#
# # PyTorch mit CUDA-Unterstützung (läuft ohne NVIDIA-GPU trotzdem auf der CPU)
# [tool.uv.sources]
# torch = [
#     { index = "pytorch-cu128", marker = "sys_platform == 'win32' or sys_platform == 'linux'" },
# ]
#
# [[tool.uv.index]]
# name = "pytorch-cu128"
# url = "https://download.pytorch.org/whl/cu128"
# explicit = true
# ///

#SBATCH --job-name=bert_slots
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=8
#SBATCH --gres=gpu:1
#SBATCH --mem=32G
#SBATCH --time=12:00:00
#SBATCH --output=%x-%j.out
#SBATCH --error=%x-%j.out

import json
import os
import random
import shutil
import subprocess
import sys
import time
from functools import partial
from pathlib import Path

# ==================================================
# BOOTSTRAP MIT UV
# ==================================================

UV_WARNUNG = """
============================================================
WARNUNG: uv wurde nicht gefunden!
============================================================
Mit uv installiert sich dieses Skript seine Bibliotheken
(PyTorch mit CUDA, Transformers) automatisch selbst.

uv installieren:
  Windows (PowerShell):
    powershell -ExecutionPolicy ByPass -c "irm https://astral.sh/uv/install.ps1 | iex"
  Linux / macOS:
    curl -LsSf https://astral.sh/uv/install.sh | sh
  Alternativ:
    pip install uv

Danach ein neues Terminal öffnen und erneut starten:
    python train.py      oder      uv run train.py

Versuche jetzt, mit dem aktuellen Python weiterzumachen...
============================================================
"""


def uv_finden():
    uv = shutil.which("uv")

    if uv:
        return uv

    # Standard-Installationsort, falls das Terminal nach der
    # Installation noch nicht neu geöffnet wurde
    for kandidat in (
        Path.home() / ".local" / "bin" / "uv.exe",
        Path.home() / ".local" / "bin" / "uv",
    ):
        if kandidat.exists():
            return str(kandidat)

    return None


def mit_uv_neu_starten():
    # "uv run" setzt die Variable UV für seine Unterprozesse,
    # TRAIN_UV_BOOTSTRAP verhindert eine Endlosschleife.
    if os.environ.get("UV") or os.environ.get("TRAIN_UV_BOOTSTRAP"):
        return

    uv = uv_finden()

    if uv is None:
        print(UV_WARNUNG, file=sys.stderr)
        return

    print("Läuft nicht über uv - starte neu mit 'uv run --script' ...", flush=True)

    try:
        ergebnis = subprocess.run(
            [uv, "run", "--script", str(Path(__file__).resolve()), *sys.argv[1:]],
            # Ungepufferte Ausgabe, damit der Fortschritt sofort im Slurm-Log steht
            env={**os.environ, "TRAIN_UV_BOOTSTRAP": "1", "PYTHONUNBUFFERED": "1"},
        )
    except KeyboardInterrupt:
        sys.exit(130)

    sys.exit(ergebnis.returncode)


if __name__ == "__main__":
    mit_uv_neu_starten()

try:
    import torch
    import torch.nn as nn
    from torch.utils.data import Dataset, DataLoader, random_split
    from transformers import (
        AutoTokenizer,
        AutoModelForSequenceClassification,
        get_linear_schedule_with_warmup,
    )
except ImportError as exc:
    sys.exit(
        f"Fehlende Bibliothek: {exc.name}\n"
        "Installiere uv (siehe Warnung oben) und starte erneut."
    )

# ==================================================
# KONFIGURATION
# ==================================================

MODEL_NAME = "google-bert/bert-base-german-cased"

DATA_FILE = Path("Trainingsdaten/Trainingsdaten_tokenisiert.jsonl")
TOKENIZER_DIR = Path("tokenizer_de")
OUTPUT_DIR = Path("bert_finetuned")
CHECKPOINT_FILE = OUTPUT_DIR / "letzter_checkpoint.pt"

# Hier landet am Ende das fertige (beste) Modell inkl. Tokenizer
FINAL_DIR = Path("fertiges_BERT_Modell")

# 0 = Kategorie kommt nicht vor
# 1 = Kategorie kommt vor
# 2 = Kategorie kommt mit Fokus vor
NUM_SLOTS = 696
NUM_CLASSES = 3
KLASSEN_NAMEN = ["nicht vorhanden", "vorhanden", "mit Fokus"]
MAX_LENGTH = 300

EPOCHS = 10
BATCH_SIZE = 32
LEARNING_RATE = 3e-5
WARMUP_ANTEIL = 0.06
VALIDATION_RATIO = 0.1
SEED = 42

# Klassengewichte = (Häufigkeit Klasse 0 / Häufigkeit Klasse k) ** GEWICHT_EXPONENT
# 0.5 gleicht die starke Unausgewogenheit aus, ohne dass das Modell
# überall 1 oder 2 vorhersagt. 0 = ungewichtet, 1 = volle Inverse.
GEWICHT_EXPONENT = 0.5

# Für schnelle Tests z.B. 5000, für das volle Training None
MAX_DATENSAETZE = None

LOG_ALLE_SCHRITTE = 200

# GPU, falls CUDA verfügbar ist, ansonsten CPU
DEVICE = torch.device(
    "cuda" if torch.cuda.is_available() else "cpu"
)

# Mixed Precision nur auf der GPU
AMP_DTYPE = None

if DEVICE.type == "cuda":
    AMP_DTYPE = (
        torch.bfloat16 if torch.cuda.is_bf16_supported()
        else torch.float16
    )


# ==================================================
# DATASET
# ==================================================

class Trainingsdaten(Dataset):

    def __init__(self, datei, max_datensaetze=None):
        self.inputs = []
        outputs = []

        if not datei.exists():
            raise FileNotFoundError(
                f"Trainingsdatei nicht gefunden: {datei}"
            )

        with datei.open("r", encoding="utf-8") as file:
            for zeilennummer, zeile in enumerate(file, start=1):
                if not zeile.strip():
                    continue

                try:
                    datensatz = json.loads(zeile)
                except json.JSONDecodeError as exc:
                    raise ValueError(
                        f"Ungültiges JSON in Zeile {zeilennummer}"
                    ) from exc

                if "input" not in datensatz or "output" not in datensatz:
                    raise ValueError(
                        f"Zeile {zeilennummer}: "
                        "'input' oder 'output' fehlt."
                    )

                input_ids = datensatz["input"]
                output = datensatz["output"]

                if not isinstance(input_ids, list) or not input_ids:
                    raise ValueError(
                        f"Zeile {zeilennummer}: input ist leer "
                        "oder keine Liste."
                    )

                if len(output) != NUM_SLOTS:
                    raise ValueError(
                        f"Zeile {zeilennummer}: Erwartet werden "
                        f"{NUM_SLOTS} Output-Slots, "
                        f"gefunden wurden {len(output)}."
                    )

                if any(
                    not isinstance(x, int)
                    or isinstance(x, bool)
                    or x not in (0, 1, 2)
                    for x in output
                ):
                    raise ValueError(
                        f"Zeile {zeilennummer}: "
                        "Output darf nur 0, 1 oder 2 enthalten."
                    )

                # Token-IDs nicht erneut tokenisieren.
                self.inputs.append(input_ids[:MAX_LENGTH])
                outputs.append(output)

                if max_datensaetze and len(self.inputs) >= max_datensaetze:
                    break

        if len(self.inputs) < 2:
            raise ValueError(
                "Mindestens zwei gültige Datensätze werden benötigt."
            )

        # Kompakt als int8-Tensor statt Python-Listen (spart viel RAM).
        # Shape: (Anzahl Datensätze, 696)
        self.outputs = torch.tensor(outputs, dtype=torch.int8)

        print(f"Geladene Datensätze: {len(self.inputs)}")

    def __len__(self):
        return len(self.inputs)

    def __getitem__(self, index):
        return self.inputs[index], self.outputs[index]


# ==================================================
# BATCHES MIT DYNAMISCHEM PADDING
# ==================================================

def batch_erstellen(batch, pad_token_id):
    input_tensors = [
        torch.tensor(input_ids, dtype=torch.long)
        for input_ids, _ in batch
    ]

    input_ids = torch.nn.utils.rnn.pad_sequence(
        input_tensors,
        batch_first=True,
        padding_value=pad_token_id,
    )

    laengen = torch.tensor([len(x) for x in input_tensors])
    positions = torch.arange(input_ids.size(1)).unsqueeze(0)
    attention_mask = (positions < laengen.unsqueeze(1)).long()

    # Shape: (Batchgröße, 696)
    labels = torch.stack([output for _, output in batch]).long()

    return input_ids, attention_mask, labels


# ==================================================
# HILFSFUNKTIONEN
# ==================================================

def klassengewichte_berechnen(training_set):
    labels = training_set.dataset.outputs[training_set.indices].long()
    anzahl = torch.bincount(labels.reshape(-1), minlength=NUM_CLASSES)

    print("\nVerteilung der Klassen im Trainingsset:")
    for klasse in range(NUM_CLASSES):
        print(
            f"  {klasse} ({KLASSEN_NAMEN[klasse]}): "
            f"{anzahl[klasse].item():>12,} "
            f"({anzahl[klasse].item() / anzahl.sum().item():.4%})"
        )

    gewichte = (anzahl[0] / anzahl.clamp(min=1)).float() ** GEWICHT_EXPONENT

    print("Klassengewichte im Loss: " + ", ".join(
        f"{klasse}={gewichte[klasse]:.2f}" for klasse in range(NUM_CLASSES)
    ))

    return gewichte


def vorwaertslauf(model, input_ids, attention_mask):
    with torch.autocast(
        device_type=DEVICE.type,
        dtype=AMP_DTYPE,
        enabled=AMP_DTYPE is not None,
    ):
        outputs = model(
            input_ids=input_ids,
            attention_mask=attention_mask,
        )

    # (Batchgröße, 2088) -> (Batchgröße, 696, 3)
    # Softmax über die letzte Achse = je Slot eine Verteilung über 0/1/2.
    # Die Softmax steckt beim Training in CrossEntropyLoss.
    return outputs.logits.float().reshape(-1, NUM_SLOTS, NUM_CLASSES)


def metriken_berechnen(konfusion):
    # konfusion[wahr, vorhergesagt]
    ergebnisse = []

    for klasse in range(NUM_CLASSES):
        tp = konfusion[klasse, klasse].item()
        fp = konfusion[:, klasse].sum().item() - tp
        fn = konfusion[klasse, :].sum().item() - tp

        precision = tp / (tp + fp) if tp + fp else 0.0
        recall = tp / (tp + fn) if tp + fn else 0.0
        f1 = (
            2 * precision * recall / (precision + recall)
            if precision + recall else 0.0
        )

        ergebnisse.append((precision, recall, f1))

    macro_f1 = sum(f1 for _, _, f1 in ergebnisse) / NUM_CLASSES

    return ergebnisse, macro_f1


def evaluieren(model, loader, loss_function):
    model.eval()

    loss_sum = 0.0
    konfusion = torch.zeros(NUM_CLASSES, NUM_CLASSES, dtype=torch.long)
    komplett_richtig = 0
    anzahl_datensaetze = 0

    with torch.no_grad():
        for input_ids, attention_mask, labels in loader:
            input_ids = input_ids.to(DEVICE)
            attention_mask = attention_mask.to(DEVICE)
            labels = labels.to(DEVICE)

            logits = vorwaertslauf(model, input_ids, attention_mask)

            loss = loss_function(
                logits.reshape(-1, NUM_CLASSES),
                labels.reshape(-1),
            )
            loss_sum += loss.item()

            predictions = logits.argmax(dim=-1)

            konfusion += torch.bincount(
                (labels * NUM_CLASSES + predictions).reshape(-1),
                minlength=NUM_CLASSES * NUM_CLASSES,
            ).reshape(NUM_CLASSES, NUM_CLASSES).cpu()

            komplett_richtig += (
                (predictions == labels).all(dim=1).sum().item()
            )
            anzahl_datensaetze += labels.size(0)

    return (
        loss_sum / len(loader),
        konfusion,
        komplett_richtig / anzahl_datensaetze,
    )


# ==================================================
# TRAINING
# ==================================================

def main():
    random.seed(SEED)
    torch.manual_seed(SEED)

    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(SEED)

    print("=" * 60)
    print("Deutsches BERT - Multi-Slot-Klassifikation")
    print("=" * 60)
    print(f"Gerät: {DEVICE}")

    if DEVICE.type == "cuda":
        print(f"GPU: {torch.cuda.get_device_name(0)}")
        print(f"Mixed Precision: {AMP_DTYPE}")
    else:
        print(f"CPU-Threads: {torch.get_num_threads()}")

    if TOKENIZER_DIR.exists():
        print(f"Lade gespeicherten Tokenizer: {TOKENIZER_DIR}")
        tokenizer = AutoTokenizer.from_pretrained(TOKENIZER_DIR)
    else:
        print("Lade Tokenizer vom Modell...")
        tokenizer = AutoTokenizer.from_pretrained(MODEL_NAME)

        TOKENIZER_DIR.mkdir(parents=True, exist_ok=True)
        tokenizer.save_pretrained(TOKENIZER_DIR)

    if tokenizer.pad_token_id is None:
        raise ValueError("Der Tokenizer besitzt kein Padding-Token.")

    print("\nLade Datensatz...")
    dataset = Trainingsdaten(DATA_FILE, MAX_DATENSAETZE)

    # 90 % Training, 10 % Validierung
    anzahl_validierung = max(
        1,
        int(len(dataset) * VALIDATION_RATIO),
    )

    anzahl_training = len(dataset) - anzahl_validierung

    generator = torch.Generator().manual_seed(SEED)

    training_set, validierung_set = random_split(
        dataset,
        [anzahl_training, anzahl_validierung],
        generator=generator,
    )

    collate = partial(batch_erstellen, pad_token_id=tokenizer.pad_token_id)

    training_loader = DataLoader(
        training_set,
        batch_size=BATCH_SIZE,
        shuffle=True,
        collate_fn=collate,
        generator=torch.Generator().manual_seed(SEED),
    )

    validierung_loader = DataLoader(
        validierung_set,
        batch_size=BATCH_SIZE * 2,
        shuffle=False,
        collate_fn=collate,
    )

    print(f"Training: {anzahl_training} | Validierung: {anzahl_validierung}")

    gewichte = klassengewichte_berechnen(training_set)

    print("\nLade vortrainiertes BERT...")
    print(f"Slots: {NUM_SLOTS}")
    print(f"Klassen je Slot: {NUM_CLASSES}")
    print(f"Ausgabelogits insgesamt: {NUM_SLOTS * NUM_CLASSES}")

    model = AutoModelForSequenceClassification.from_pretrained(
        MODEL_NAME,
        num_labels=NUM_SLOTS * NUM_CLASSES,
    )

    model.to(DEVICE)

    # Jede Position ist eine eigene Drei-Klassen-Klassifikation (Softmax je Slot).
    loss_function = nn.CrossEntropyLoss(weight=gewichte.to(DEVICE))

    optimizer = torch.optim.AdamW(
        model.parameters(),
        lr=LEARNING_RATE,
        weight_decay=0.01,
    )

    gesamt_schritte = len(training_loader) * EPOCHS

    scheduler = get_linear_schedule_with_warmup(
        optimizer,
        num_warmup_steps=int(gesamt_schritte * WARMUP_ANTEIL),
        num_training_steps=gesamt_schritte,
    )

    # GradScaler nur bei float16 nötig
    scaler = torch.amp.GradScaler(
        "cuda",
        enabled=AMP_DTYPE == torch.float16,
    )

    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

    start_epoch = 0
    best_macro_f1 = -1.0

    # Abgebrochenes Training fortsetzen
    if CHECKPOINT_FILE.exists():
        print(f"\nSetze Training fort aus: {CHECKPOINT_FILE}")
        checkpoint = torch.load(CHECKPOINT_FILE, map_location=DEVICE)

        model.load_state_dict(checkpoint["model"])
        optimizer.load_state_dict(checkpoint["optimizer"])
        scheduler.load_state_dict(checkpoint["scheduler"])
        scaler.load_state_dict(checkpoint["scaler"])

        start_epoch = checkpoint["epoch"] + 1
        best_macro_f1 = checkpoint["best_macro_f1"]

    print(f"\nSchritte pro Epoche: {len(training_loader)}")

    for epoch in range(start_epoch, EPOCHS):
        model.train()

        train_loss_sum = 0.0
        startzeit = time.time()

        for schritt, (input_ids, attention_mask, labels) in enumerate(
            training_loader, start=1
        ):
            input_ids = input_ids.to(DEVICE)
            attention_mask = attention_mask.to(DEVICE)
            labels = labels.to(DEVICE)

            optimizer.zero_grad()

            logits = vorwaertslauf(model, input_ids, attention_mask)

            # CE erwartet Klassen-IDs 0, 1 oder 2.
            loss = loss_function(
                logits.reshape(-1, NUM_CLASSES),
                labels.reshape(-1),
            )

            scaler.scale(loss).backward()

            # Stabileres Training
            scaler.unscale_(optimizer)
            torch.nn.utils.clip_grad_norm_(
                model.parameters(),
                max_norm=1.0,
            )

            scaler.step(optimizer)
            scaler.update()
            scheduler.step()

            train_loss_sum += loss.item()

            if schritt % LOG_ALLE_SCHRITTE == 0:
                vergangen = time.time() - startzeit
                rest = vergangen / schritt * (len(training_loader) - schritt)

                print(
                    f"  Epoch {epoch + 1:02} | "
                    f"Schritt {schritt}/{len(training_loader)} | "
                    f"Loss: {train_loss_sum / schritt:.4f} | "
                    f"Rest der Epoche: ~{rest / 60:.0f} min"
                )

        train_loss = train_loss_sum / len(training_loader)

        # ==================================================
        # VALIDIERUNG
        # ==================================================

        val_loss, konfusion, exakt = evaluieren(
            model, validierung_loader, loss_function
        )
        klassen_metriken, macro_f1 = metriken_berechnen(konfusion)

        print(
            f"\nEpoch {epoch + 1:02}/{EPOCHS} | "
            f"Train Loss: {train_loss:.4f} | "
            f"Val Loss: {val_loss:.4f} | "
            f"Macro-F1: {macro_f1:.4f} | "
            f"Alle Slots richtig: {exakt:.2%} | "
            f"Dauer: {(time.time() - startzeit) / 60:.1f} min"
        )

        for klasse, (precision, recall, f1) in enumerate(klassen_metriken):
            print(
                f"  Klasse {klasse} ({KLASSEN_NAMEN[klasse]:<15}) | "
                f"Precision: {precision:.4f} | "
                f"Recall: {recall:.4f} | "
                f"F1: {f1:.4f}"
            )

        print("  Konfusionsmatrix (Zeile = wahr, Spalte = vorhergesagt):")
        for klasse in range(NUM_CLASSES):
            print("    " + " ".join(
                f"{wert:>12,}" for wert in konfusion[klasse].tolist()
            ))

        # Bestes Modell anhand des Macro-F1 über 0, 1 und 2 speichern
        if macro_f1 > best_macro_f1:
            best_macro_f1 = macro_f1

            model.save_pretrained(OUTPUT_DIR)
            tokenizer.save_pretrained(OUTPUT_DIR)

            with (OUTPUT_DIR / "slot_config.json").open(
                "w", encoding="utf-8"
            ) as file:
                json.dump({
                    "num_slots": NUM_SLOTS,
                    "num_classes": NUM_CLASSES,
                    "klassen": KLASSEN_NAMEN,
                    "epoch": epoch + 1,
                    "macro_f1": macro_f1,
                }, file, ensure_ascii=False, indent=2)

            print("  -> Bestes Modell gespeichert.")

        torch.save({
            "model": model.state_dict(),
            "optimizer": optimizer.state_dict(),
            "scheduler": scheduler.state_dict(),
            "scaler": scaler.state_dict(),
            "epoch": epoch,
            "best_macro_f1": best_macro_f1,
        }, CHECKPOINT_FILE)

    # Bestes Modell (ohne den großen Trainings-Checkpoint) als fertiges Modell ablegen
    shutil.copytree(
        OUTPUT_DIR,
        FINAL_DIR,
        ignore=shutil.ignore_patterns(CHECKPOINT_FILE.name),
        dirs_exist_ok=True,
    )

    print("\nTraining abgeschlossen.")
    print(f"Bester Macro-F1: {best_macro_f1:.4f}")
    print(f"Fertiges Modell gespeichert unter: {FINAL_DIR.resolve()}")


# ==================================================
# VORHERSAGE
# ==================================================

def vorhersagen(text, model_dir=FINAL_DIR):
    """Gibt für einen Text eine Liste mit 696 Werten (0, 1 oder 2) zurück."""
    tokenizer = AutoTokenizer.from_pretrained(model_dir)
    model = AutoModelForSequenceClassification.from_pretrained(model_dir)
    model.to(DEVICE)
    model.eval()

    tokens = tokenizer(
        text,
        truncation=True,
        max_length=MAX_LENGTH,
        return_tensors="pt",
    ).to(DEVICE)

    with torch.no_grad():
        logits = vorwaertslauf(
            model, tokens["input_ids"], tokens["attention_mask"]
        )

    # Wahrscheinlichkeiten je Slot: torch.softmax(logits, dim=-1)
    return logits.argmax(dim=-1)[0].tolist()


if __name__ == "__main__":
    main()
